/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fillit_solver.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kdumarai <kdumarai@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/11/14 18:01:59 by kdumarai          #+#    #+#             */
/*   Updated: 2017/11/16 19:31:10 by kdumarai         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fillit.h"

static int		get_piece_start(char **allpieces)
{
	int		x;
	int		y;
	int		startx;
	int		starty;

	starty = -1;
	startx = -1;
	y = 0;
	while (y < 4)
	{
		x = 0;
		while (x < 4)
		{
			if (allpieces[y][x] == '#')
			{
				if (x < startx || startx == -1)
					startx = x;
				if (starty == -1)
					starty = y;
			}
			x++;
		}
		y++;
	}
	return (startx * 10 + starty);
}

void	modify_board(char **board, char **piece, int x, int y)
{
	int		startpoint;
	int		sx;
	int		sy;

	startpoint = get_piece_start(allpieces);
	sx = (startpoint < 0) ? 0 : startpoint / 10;
	sy = startpoint % 10;
	while (y < 4 && x < 4)
	{
		while (x < 4)
		{
			if (allpieces[sy][sx] == '#')
				board[y][x] = '#';
			if (sx == 3)
				break ;
			sx++;
			x++;
		}
		sy++;
		y++;
	}
}

int		does_it_fit(char **allpieces, char **board, int x, int y)
{
	int		startpoint;
	int		sx;
	int		sy;

	startpoint = get_piece_start(allpieces);
	sx = (startpoint < 0) ? 0 : startpoint / 10;
	sy = startpoint % 10;
	while (y < 4 && x < 4)
	{
		while (x < 4)
		{
			if (board[y][x] == '#' && allpieces[sy][sx] == '#')
				return (0);
			if (sx == 3)
				break ;
			sx++;
			x++;
		}
		sy++;
		y++;
	}
	return (1);
}

int		solve_fillit(char **allpieces, char **board)
{
	int		bouds;
	int		x;
	int		y;

	bouds = 3; /* 4 - 1 */
	while (++bounds < 104) /* Place to fit 26 pieces (not sort) */
	{
		y = -1;
		while (++y < bounds)
		{
			x = -1;
			while (++x < bounds)
			{
				if (does_it_fit(allpieces, board, x, y))
				{
					// place on board
					if (solve_fillit(allpieces + 5, board)) /* 4 elems per piece + 1 blank (\n) */	
						return (1);
				}
				// remove from board
			}
		}
	}
	return (0);
}
